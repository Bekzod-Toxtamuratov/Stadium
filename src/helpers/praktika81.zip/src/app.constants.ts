export const BotName = 'Avtomoyka';
